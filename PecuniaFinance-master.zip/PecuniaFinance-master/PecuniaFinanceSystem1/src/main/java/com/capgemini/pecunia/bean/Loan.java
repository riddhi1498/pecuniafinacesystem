package com.capgemini.pecunia.bean;

public class Loan {

}

package com.capgemini.pecunia.controller;

public class TransactionController {

}

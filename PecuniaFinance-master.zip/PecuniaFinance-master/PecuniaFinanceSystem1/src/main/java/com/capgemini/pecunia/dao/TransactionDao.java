package com.capgemini.pecunia.dao;

public class TransactionDao {

}

package com.capgemini.pecunia.dao;

public interface TransactionDaoImpl {

}

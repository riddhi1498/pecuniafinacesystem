package com.capgemini.pecunia.service;

public class LoanService {

}

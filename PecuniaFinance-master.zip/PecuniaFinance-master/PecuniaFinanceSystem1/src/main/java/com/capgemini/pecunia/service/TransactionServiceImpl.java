package com.capgemini.pecunia.service;

public interface TransactionServiceImpl {

}

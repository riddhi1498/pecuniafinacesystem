package com.cg.pecu.util;

import com.cg.pecu.exception.LoandeniedException;

@SuppressWarnings("unused")
public class UserValidation {
	
	}
	